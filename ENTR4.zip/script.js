window.addEventListener('load', () => {
    const gameBoard = document.getElementById('game-board');
    const scoreElement = document.getElementById('score');
    const lifePercentage = document.getElementById('life-percentage');
    const levelElement = document.getElementById('level');
    const highscoreElement = document.getElementById('highscore');
    const pauseButton = document.getElementById('pause-btn');
    const speedSlider = document.getElementById('speed-slider');
    const lifeBarFill = document.getElementById('life-bar-fill');

    let gameInterval;
    let obstacleInterval;
    let snake = [{ x: 4, y: 4 }];
    let direction = 'RIGHT';
    let food = { x: 6, y: 6 };
    let obstacles = [];
    let speed = 3;
    let score = 0;
    let life = 100;
    let level = 1;
    let highScore = 0;
    let isPaused = true; // Initially, game is paused
    let gridSize = 10;
    let currentFoodImage;

    // Load sound files
    const sounds = {
        bush: new Audio('audio/bushh.mp3'),
        tree: new Audio('audio/treee.mp3'),
        rock: new Audio('audio/rockk.mp3'),
        food1: new Audio('audio/foodd1.mp3'),
        food2: new Audio('audio/foodd2.mp3'),
        lose: new Audio('audio/lose.mp3') // Added lose sound effect
    };

    // Play sound function to avoid overlapping
    function playSound(sound) {
        if (sound.paused || sound.ended) {
            sound.currentTime = 0; // Restart sound if already playing
            sound.play();
        }
    }

    // Create the game board grid
    function createGameBoard(size) {
        gameBoard.innerHTML = '';
        gameBoard.style.gridTemplateColumns = `repeat(${size}, 32px)`;
        gameBoard.style.gridTemplateRows = `repeat(${size}, 32px)`;
        gameBoard.style.width = `${32 * size}px`;  // Dynamically set the width
        gameBoard.style.height = `${32 * size}px`; // Dynamically set the height

        for (let i = 0; i < size * size; i++) {
            const cell = document.createElement('div');
            cell.classList.add('cell');
            gameBoard.appendChild(cell);
        }
    }

    // Draw game state (snake, food, obstacles)
    function drawGame() {
        const cells = gameBoard.children;
        Array.from(cells).forEach(cell => {
            cell.style.backgroundImage = ''; // Clear all images
            cell.style.transform = ''; // Reset transformations
        });

        // Draw snake
        snake.forEach((segment, index) => {
            const cellIndex = segment.y * gridSize + segment.x;
            const imageUrl = index === 0 ? 'fotos/head.png' : 'fotos/body.png'; // Head or body
            cells[cellIndex].style.backgroundImage = `url(${imageUrl})`;

            if (index === 0) {
                const rotation = {
                    'UP': 'rotate(270deg)',
                    'DOWN': 'rotate(90deg)',
                    'LEFT': 'rotate(180deg)',
                    'RIGHT': 'rotate(0deg)'
                }[direction];
                cells[cellIndex].style.transform = rotation;
            }
        });

        // Draw food
        const foodIndex = food.y * gridSize + food.x;
        cells[foodIndex].style.backgroundImage = `url(${currentFoodImage})`;

        // Draw obstacles
        obstacles.forEach(obstacle => {
            const cellIndex = obstacle.y * gridSize + obstacle.x;
            const obstacleImage = `fotos/${obstacle.type}.png`;
            cells[cellIndex].style.backgroundImage = `url(${obstacleImage})`;
        });
    }

    // Handle key press (left, right, up, down)
    function handleKeyPress(event) {
        if (event.key === 'ArrowUp' && direction !== 'DOWN') {
            direction = 'UP';
        } else if (event.key === 'ArrowDown' && direction !== 'UP') {
            direction = 'DOWN';
        } else if (event.key === 'ArrowLeft' && direction !== 'RIGHT') {
            direction = 'LEFT';
        } else if (event.key === 'ArrowRight' && direction !== 'LEFT') {
            direction = 'RIGHT';
        }
    }

    // Handle swipe gestures (for mobile)
    let touchStartX = 0;
    let touchStartY = 0;

    function handleTouchStart(event) {
        const touch = event.touches[0];
        touchStartX = touch.pageX;
        touchStartY = touch.pageY;
    }

    function handleTouchMove(event) {
        if (event.touches.length === 1) {
            const touch = event.touches[0];
            const touchEndX = touch.pageX;
            const touchEndY = touch.pageY;

            const diffX = touchEndX - touchStartX;
            const diffY = touchEndY - touchStartY;

            // Determine swipe direction (up, down, left, right)
            if (Math.abs(diffX) > Math.abs(diffY)) {
                if (diffX > 0 && direction !== 'LEFT') {
                    direction = 'RIGHT';
                } else if (diffX < 0 && direction !== 'RIGHT') {
                    direction = 'LEFT';
                }
            } else {
                if (diffY > 0 && direction !== 'UP') {
                    direction = 'DOWN';
                } else if (diffY < 0 && direction !== 'DOWN') {
                    direction = 'UP';
                }
            }

            // Reset touch start values after processing the swipe
            touchStartX = touchEndX;
            touchStartY = touchEndY;
        }
    }

    // Game loop: Move snake, check for food, collisions, etc.
    function gameLoop() {
        if (isPaused) return;

        const head = { ...snake[0] };

        // Move snake
        if (direction === 'UP') head.y--;
        if (direction === 'DOWN') head.y++;
        if (direction === 'LEFT') head.x--;
        if (direction === 'RIGHT') head.x++;

        // Handle board edges (wrap around)
        if (head.x < 0) head.x = gridSize - 1;
        if (head.x >= gridSize) head.x = 0;
        if (head.y < 0) head.y = gridSize - 1;
        if (head.y >= gridSize) head.y = 0;

        // Check for collision with snake's body
        if (snake.some(segment => segment.x === head.x && segment.y === head.y)) {
            endGame();
            return;
        }

        // Check for obstacle collision
        const obstacleHitIndex = obstacles.findIndex(obstacle => obstacle.x === head.x && obstacle.y === head.y);
        if (obstacleHitIndex !== -1) {
            const obstacle = obstacles[obstacleHitIndex];
            if (obstacle.type === 'bush') {
                playSound(sounds.bush);
            } else if (obstacle.type === 'tree') {
                playSound(sounds.tree);
            } else if (obstacle.type === 'rock') {
                playSound(sounds.rock);
            }

            life -= obstacle.damage;
            obstacles.splice(obstacleHitIndex, 1); // Remove the obstacle
            updateLifeBar();
            if (life <= 0) {
                endGame();
                return;
            }
        }

        snake.unshift(head); // Add new head

        // Check if snake eats food
        if (head.x === food.x && head.y === food.y) {
            score += 10;
            increaseHealth(1);
            levelUp();
            generateFood();

            // Play a random food sound
            const randomFoodSound = Math.random() < 0.5 ? sounds.food1 : sounds.food2;
            playSound(randomFoodSound);
        } else {
            snake.pop(); // Remove last segment (tail)
        }

        scoreElement.innerText = score;
        levelElement.innerText = level;
        highscoreElement.innerText = highScore;

        drawGame();
    }

    // Generate food, ensuring no overlap with snake or obstacles
    function generateFood() {
        do {
            food = {
                x: Math.floor(Math.random() * gridSize),
                y: Math.floor(Math.random() * gridSize)
            };
        } while (
            snake.some(segment => segment.x === food.x && segment.y === food.y) ||
            obstacles.some(obstacle => obstacle.x === food.x && obstacle.y === food.y)
        );

        // Randomize food image
        const foodImages = [
            'fotos/food1.png',
            'fotos/food2.png',
            'fotos/food3.png',
            'fotos/food4.png',
            'fotos/food5.png'
        ];
        currentFoodImage = foodImages[Math.floor(Math.random() * foodImages.length)];
    }

    // Generate obstacles, ensuring no overlap with snake, food, or other obstacles
    function generateNewObstacle() {
        const obstacleType = Math.random() < 0.75 ? 'bush' : Math.random() < 0.95 ? 'tree' : 'rock';
        let newObstacle;
        do {
            newObstacle = {
                x: Math.floor(Math.random() * gridSize),
                y: Math.floor(Math.random() * gridSize),
                type: obstacleType,
                damage: obstacleType === 'bush' ? 10 : obstacleType === 'tree' ? 25 : 50
            };
        } while (
            snake.some(segment => segment.x === newObstacle.x && segment.y === newObstacle.y) ||
            obstacles.some(obstacle => obstacle.x === newObstacle.x && obstacle.y === newObstacle.y) ||
            (food.x === newObstacle.x && food.y === newObstacle.y)
        );

        obstacles.push(newObstacle);
    }

    // Increase snake's health after eating food
    function increaseHealth(amount) {
        life = Math.min(life + amount, 100);
        updateLifeBar();
    }

    // Update the life bar
    function updateLifeBar() {
        const percentage = Math.max(0, Math.min(100, life));
        lifeBarFill.style.width = `${percentage}%`;
        lifePercentage.textContent = `${Math.floor(percentage)}%`;
    }

    // Update obstacle interval based on level, capped at 5 seconds
    function updateObstacleInterval() {
        let newInterval = Math.max(5000, 8000 - (level - 1) * 1000); // Starts at 8 seconds (8000ms), reduces by 1 second per level, but not below 5 seconds (5000ms)
        clearInterval(obstacleInterval); // Clear the previous interval
        obstacleInterval = setInterval(generateNewObstacle, newInterval); // Set the new interval
    }

    // Level up the game
    function levelUp() {
        if (score % 150 === 0 && score <= 450) {
            level++;
            gridSize = level + 9;
            createGameBoard(gridSize);
            drawGame();
            updateObstacleInterval(); // Update the obstacle interval when the level increases
        }
    }

    // Toggle pause/resume
    function togglePause() {
        if (isPaused) {
            isPaused = false;
            gameInterval = setInterval(gameLoop, 1000 / speed);
            obstacleInterval = setInterval(generateNewObstacle, 8000);
            pauseButton.innerText = 'Pause';
        } else {
            isPaused = true;
            clearInterval(gameInterval);
            clearInterval(obstacleInterval);
            pauseButton.innerText = 'Resume';
        }
    }

    // End the game and play lose sound
    function endGame() {
        playSound(sounds.lose); // Play lose sound
        alert(`Game Over! Final Score: ${score}`);
        if (score > highScore) {
            highScore = score;
            highscoreElement.innerText = highScore;
        }
        isPaused = true; // Ensure the game starts paused after game over
        clearInterval(gameInterval); // Stop the game loop
        clearInterval(obstacleInterval); // Stop obstacle generation
        pauseButton.innerText = 'Resume'; // Update the button text to indicate the game is paused
        resetGame();
    }

    function resetGame() {
        snake = [{ x: 4, y: 4 }];
        score = 0;
        level = 1;
        life = 100;
        direction = 'RIGHT';
        gridSize = 10;
        obstacles = [];
        createGameBoard(gridSize);
        generateFood();
        drawGame();
        updateLifeBar();
    }

    // Event listeners
    document.addEventListener('keydown', handleKeyPress);
    speedSlider.addEventListener('input', (e) => {
        speed = parseInt(e.target.value);
        if (!isPaused) {
            clearInterval(gameInterval);
            gameInterval = setInterval(gameLoop, 1000 / speed);
        }
    });

    pauseButton.addEventListener('click', togglePause);

    // Touch event listeners for mobile swipe control
    window.addEventListener('touchstart', handleTouchStart);
    window.addEventListener('touchmove', handleTouchMove);

    // Disable page scrolling on mobile
    window.addEventListener('touchmove', function(e) {
        e.preventDefault();
    }, { passive: false });

    // Initialize game
    createGameBoard(gridSize);
    generateFood();
    drawGame();
    updateLifeBar();

    // Don't start the game loop until the user presses the pause button
});
